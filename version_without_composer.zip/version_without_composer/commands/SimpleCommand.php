<?php

class SimpleCommand extends SmartCommand
{
    public function execute(): void
    {
        echo "This is only checking working \n";
    }
}
